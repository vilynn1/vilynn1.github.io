define({
  "_widgetLabel": "Contrôleur d’en-tête",
  "signin": "Se connecter",
  "signout": "Se déconnecter",
  "about": "À propos",
  "signInTo": "Se connecter à",
  "cantSignOutTip": "Cette fonction est N/D en mode d’aperçu.",
  "more": "plus"
});