define({
  "_themeLabel": "Jewelry Box téma",
  "_layout_default": "Alapértelmezett elrendezés",
  "_layout_layout1": "1. elrendezés",
  "emptyDocablePanelTip": "Kattintson a + gombra a Widget fülön egy widget hozzáadásához. "
});