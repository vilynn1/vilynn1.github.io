define({
  "_themeLabel": "ジュエリー ボックス テーマ",
  "_layout_default": "デフォルトのレイアウト",
  "_layout_layout1": "レイアウト 1",
  "emptyDocablePanelTip": "[ウィジェット] タブで [+] ボタンをクリックしてウィジェットを追加します。 "
});