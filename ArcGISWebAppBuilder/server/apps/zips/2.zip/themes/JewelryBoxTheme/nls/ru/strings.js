define({
  "_themeLabel": "Тема \"шкатулка\"",
  "_layout_default": "Компоновка по умолчанию",
  "_layout_layout1": "Компоновка 1",
  "emptyDocablePanelTip": "Щелкните кнопку + на закладке Виджет, чтобы добавить виджет. "
});