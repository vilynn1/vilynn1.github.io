define({
  "_themeLabel": "Smykkeskrin-tema",
  "_layout_default": "Standardoppsett",
  "_layout_layout1": "Oppsett 1",
  "emptyDocablePanelTip": "Klikk på + knappen i Miniprogram-kategorien for å legge til et miniprogram. "
});