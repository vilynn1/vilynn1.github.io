define({
  "_themeLabel": "보석 상자 테마",
  "_layout_default": "기본 레이아웃",
  "_layout_layout1": "레이아웃 1",
  "emptyDocablePanelTip": "위젯을 추가하려면 위젯 탭에서 + 버튼을 클릭합니다. "
});