define({
  "_themeLabel": "Тема Jewelry Box",
  "_layout_default": "Компонування за замовчуванням",
  "_layout_layout1": "Компонування 1",
  "emptyDocablePanelTip": "Клацніть кнопку + у вкладці «Віджет», щоб додати віджет. "
});