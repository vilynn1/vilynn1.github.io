define({
  "_themeLabel": "Tema Kutija za nakit",
  "_layout_default": "Podrazumevani raspored",
  "_layout_layout1": "Raspored 1",
  "emptyDocablePanelTip": "Kliknite na dugme „+“ u kartici vidžeta da biste dodali vidžet. "
});