define({
  "_themeLabel": "Temă cutie bijuterii",
  "_layout_default": "Aspect implicit",
  "_layout_layout1": "Aspectul 1",
  "emptyDocablePanelTip": "Faceţi clic pe butonul + din fila Widget pentru a adăuga un widget. "
});