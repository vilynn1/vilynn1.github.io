define({
  "_themeLabel": "Motyw Pudełko z biżuterią",
  "_layout_default": "Kompozycja domyślna",
  "_layout_layout1": "Układ 1",
  "emptyDocablePanelTip": "Aby dodać widżet, kliknij na karcie Widżet przycisk „+”. "
});